<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$config['whatsapp_api_product_item_id'] = "38690826";
$config["whatsapp_api_product_token"] = "";
