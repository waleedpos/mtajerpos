#!/bin/bash
php server.php
